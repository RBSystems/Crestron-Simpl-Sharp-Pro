﻿using System.Reflection;

[assembly: AssemblyTitle("S_100_Template")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("S_100_Template")]
[assembly: AssemblyCopyright("Copyright ©  2017")]
[assembly: AssemblyVersion("1.0.0.*")]

